
public class Hello {

	public static void main(String[] args) {
		System.out.println("Hello World");
	byte erstes = 1;	
	byte zweites = 2;
	short drittes = 3;
	short viertes = 4;
	int f�nftes = 5;
	int sechstes = 6;
	long siebtes = 7;
	long achtes = 8;
	float neuntes = 9;
	float zehntes = 10;
	double elftes = 11;
	double zw�lftes = 12;
	char dreizehntes = 'n'; 
	char vierzehntes = 'p';
	System.out.println(erstes+" "+zweites+" "+drittes+" "+viertes+" "+f�nftes+" "+
						sechstes+" "+siebtes+" "+achtes+" "+neuntes+" "+zehntes
						+" "+elftes+" "+zw�lftes+" "+dreizehntes+" "+vierzehntes);
	}
	
}
