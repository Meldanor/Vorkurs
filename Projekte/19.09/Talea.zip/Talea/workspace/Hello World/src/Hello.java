
public class Hello {

	public static void main(String[] args) {
		System.out.println("Ich bin Batman!");
		
		byte eins = 1;
		byte zwei = 2;
		System.out.println(eins);
		eins = 4;
		System.out.println(eins);
		
		short drei = 3;
		short vier = 4;
		System.out.println(vier);
		
		int zwanzig = 20;
		int zehn = 10;
		System.out.println(zehn);
		
		long zweihundert = 200L;
		long hundert = 100L;
		
		vier = 5;
		zehn = 40;
		System.out.println(vier);
		System.out.println(zehn);
		
		double mep = 1.0/7.0;
		System.out.println(mep);
		
		boolean wahr = true;
		boolean falsch = false;
		
	
	}
}

