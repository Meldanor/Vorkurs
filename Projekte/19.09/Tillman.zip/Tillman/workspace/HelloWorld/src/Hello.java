
public class Hello {
	public static void main(String[]args) {
		System.out.println("fighjdfjdnfgi491�^1�308efjdy");
		byte b=1;
		short s=12;
		int i=11;
		long l=3;
		System.out.println(s);
		double d=1.3;
		float f=1.2F;
		
		s=13;
		System.out.println(s);
		char a='f';
		char B='B';
		System.out.println(a);
	}
}
