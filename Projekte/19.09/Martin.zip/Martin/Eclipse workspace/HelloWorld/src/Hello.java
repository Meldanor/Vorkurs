
public class Hello 
{
	public static void main(String[] args) 
    {
      System.out.println("Hallo Vorkurs!");
     
      	int all = 10;
      	{System.out.println(all);
      	}
      	double durchschnitt = 134.54;
      	{System.out.println(durchschnitt);
      
      	}
      	long d = 34;
      	{System.out.println(d);
      	
      	}
      	
      	
    }


   
    

} 

