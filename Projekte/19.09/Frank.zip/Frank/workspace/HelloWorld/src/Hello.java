
public class Hello {
	
	public static void main(String[] args) {
			System.out.println("Der Computer ist doof");
			
		int bla = 15;
		int zwei = 2;
		long tralala = 1500L;
		long blablub = 31L;
		short s = 2;
		short blabliblu = 33;
		byte bite = 10;
		byte tralalo = 0;
		
		float dr�lf = 0.3F;
		double peter = 2.2;
		
		
		char a = 'A';
		char b = 'B';
		
		System.out.println (b);
		System.out.println(tralala);
		
	}
}

/*
MarcoPolo-Massenmord 
*/


