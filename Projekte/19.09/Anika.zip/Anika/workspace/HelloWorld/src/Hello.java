
public class Hello {

	public static void main(String[] args) {
		System.out.println("Hallo Vorkurs");
		byte b = 1;
		System.out.println(b);
		short s = 10;
		System.out.println(s);
		int i = 100;
		System.out.println(i);
		long l = 1000;
		System.out.println(l);
		
		double bruch = 1.3;
		System.out.println(bruch);
		
		boolean wahr = true;
		System.out.println(wahr);
		boolean falsch = false;
		System.out.println(falsch);
		
		char a = 'a';
		System.out.println(a);
		
		
		b = 2;
		System.out.println(b);
		s = 20;
		System.out.println(s);
		i = 200;
		System.out.println(i);
		l = 2000;
		System.out.println(l);
		
		bruch = 2.3;
		System.out.println(bruch);
		
		String s1 = "hallo";
		String s2 = "hallo";
		System.out.println(s1 == s2);
		System.out.println(s1.equals(s2));	//besser
		
	}
}
