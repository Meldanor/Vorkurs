
public class Hello {
	public static void main(String[] args) {
		System.out.println("Hallo Vorkurs");	
		int zahl1 = 333;
		System.out.println(zahl1);
		int zahl2 = 555;
		System.out.println(zahl2);
		double bruch1 = 1.234;
		System.out.println(bruch1);
		double bruch2 = 2.456;
		System.out.println(bruch2);
		char xyz = 'a';
		System.out.println(xyz);
		char abc = 'b';
		System.out.println(abc);
		int zahl3 = 2+2+2;
		System.out.println(zahl3);
	}
}

