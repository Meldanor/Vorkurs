
public class Hello {

	public static void main(String[] args) {
		System.out.println("Hallo Vorkurs");//Heyho let's go
		byte zahl = 3;
		System.out.println(zahl);
		byte mini = 1;
		System.out.println(mini);
		short klein = 345;
		System.out.println(klein);
		short hundert = 100;
		System.out.println(hundert);
		int mittel = 780;
		System.out.println(mittel);
		int tausend = 1000;
		System.out.println(tausend);
		long riesig = 5403L;
		System.out.println(riesig);
		riesig = 436764L;
		System.out.println(riesig);
		
		double bruch = 25.0/6.0;
		System.out.println(bruch);
		
		boolean wahr = true;
		boolean falsch = false;
		
		System.out.println(wahr);
		System.out.println(falsch);
		
		double boom = 564754.0/46567.0;
		System.out.println(boom);

		double produkt = 6*7;
		System.out.println(produkt);
		
		
	}
}
