
public class Hello {
	
	public static void main(String[] args) {
		System.out.println("Hallo Vorkurs"); 
		byte b = 1;
		System.out.println(b);
		short s = 10;
		System.out.println(s);
		int i = 100;
		System.out.println(i);
		long l = 1000;
		System.out.println(l);
		
		
		
		String text = "Hallo Vorkurs!"; 
		System.out.println(text); 
		text = text + "Gleich Schluss!"; 
		System.out.println(text);
		String s1 = "hallo"; 
		String s2 = "halol"; 
// 		System.out.println(s1 == s2); 
		System.out.print(s1.equals(s2)); 
		
	}
}
