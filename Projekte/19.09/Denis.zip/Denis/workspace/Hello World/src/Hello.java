
public class Hello {
	
	public static void main(String[] args) { // hey , einzeiliger kommentar
		System.out.println("Hey Welt");
		/* test
		 * mehrzeiliger Kommentar
		 */
		int i = 256;
		int k ; 
				k  = 7895257;
		short s = 48;
		short sh;
				sh = 84;
		long dong = 123456789L;
		long test;
				test = 123456765L;
		char J = 'y';
		char Y;
		 	 Y = 'J';
		String text = "hey hey hey";
		String text2;
		text2 = "was was was ?";
		boolean richtig = false;
		boolean falsch;
		 falsch = true;
		 double kom= 3.14;
		 double ma;
		 ma = 2.17;
		 System.out.println(i+" "+k+" "+s+" "+sh+" "+dong+" "+test+" "+J+" "+Y+" "+text+" "+text2+" "+richtig+" "+falsch
				 			+" "+kom+" "+ma);
		 String s1 = "hallo";
		 String s2 = "hallo";
		 System.out.println(s1 ==s2);
		 System.out.println(s1.equals(s2)); // equals= besser
				 
		 
				
	}
}
