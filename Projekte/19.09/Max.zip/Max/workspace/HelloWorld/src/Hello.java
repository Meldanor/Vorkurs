
public class Hello {
	public static void main(String[] args) {
		System.out.println("Hallo Vorkurs!");
		byte b = 0;
		System.out.println(b);
		short r = 12;
		System.out.println(r);
		int i = 100;
		System.out.println(i);
		long k = 512;
		System.out.println(k);
		float f = 1.3f;
		System.out.println(f);
		double d = 1.2;
		System.out.println(d);
		char a = 'a';
		System.out.println(a);
		String s = "Hallo!";
		System.out.println(s);
	}

}
