
public class Hello {
	
	public static void main(String[] args) {
	
		
	System.out.println("Hello World.");
	byte a = 10;
	System.out.println(a);
	byte b = 20;
	System.out.println(b);
	b = 30;
	System.out.println(b);
	short c = 100;
	System.out.println(c);
	short d = 200;
	System.out.println(d);
	d = 300;
	System.out.println(d);
	
	int e = 1000;
	System.out.println(e);
	int f = 2000;
	System.out.println(f);
	f = 3000;
	System.out.println(f);
	
	long g = 20000;
	System.out.println(g);
	long h = 10000;
	System.out.println(h);
	h = 30000;
	System.out.println(h);
	
	float i = 50/2;
	System.out.println(i);
	float j = 360/6;
	System.out.println(j);
	j = 3420/9;
	System.out.println(j);
	
	double k = 35624578;
	System.out.println(k);
	double l = 13491243;
	System.out.println(l);
	l = 1234859;
	System.out.println(l);
	
	boolean m = true; 
	System.out.println(m);
	boolean n = false;
	System.out.println(n);
	n = true;
	System.out.println(n);
	
	char o = 'p';
	System.out.println(o);
	char p = 'o';
	System.out.println(p);
	p = 'q';
	System.out.println(p);
	
	
	}
}
