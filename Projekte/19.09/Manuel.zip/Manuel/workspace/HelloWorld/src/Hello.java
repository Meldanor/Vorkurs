
public class Hello {

	public static void main(String[]args){
	int zahl1 = 13;			int zahl2;	
		
	float zahl3 = 3.7F;		float zahl4;
	double zahl5= 8.67;		double zahl6;
	byte zahl7=8;			byte zahl8;
	short zahl9 = 34;		short zahl10;
	long  zahl11 =66;		long zahl12;	
	char zeichen1 ='a';		char zeichen2;	
	boolean richtig=true;	boolean falsch;
	
	
	
	zahl2 = 45;
	zahl4 = 8.9F;
	zahl6 = 13.8;
	zahl8 = 3;
	zahl10 = 60;
	zahl12 = 1000;
	zeichen2 = 'B';	
	falsch = false;	
		
	System.out.println(zahl1);System.out.println(zahl2);
	System.out.println(zahl3);System.out.println(zahl4);
	System.out.println(zahl5);System.out.println(zahl6);
	System.out.println(zahl7);System.out.println(zahl8);
	System.out.println(zahl9);System.out.println(zahl10);
	System.out.println(zahl11);System.out.println(zahl12);
	
	System.out.println(zeichen1);System.out.println(zeichen2);
	System.out.println(richtig);System.out.println(falsch);
	
	
				
	}
}
